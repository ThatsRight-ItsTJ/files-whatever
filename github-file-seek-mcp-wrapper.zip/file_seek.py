"""Utility functions used by the FastAPI app.
This file contains helper functions for interacting with the GitHub API.
"""
# (Left intentionally minimal; logic lives in main.py for the scaffold.)
