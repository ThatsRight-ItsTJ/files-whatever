# Oracle fallback worker

This minimal worker executes jobs only when explicit consent is provided (either in request body or in signed envelope payload).